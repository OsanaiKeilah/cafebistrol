<x-layout title="Novo Cafe">
    <form action="" method="POST">
        <div class="mb-3">
            <label for ="nome" class="form-label">Nome:</label>
            <input type="text" id="nome" name="nome" class="form-control">
</div>
<label for="name">Nome: </label>
        <input type="text" id="name" name="name">
    </form>
</x-layout>